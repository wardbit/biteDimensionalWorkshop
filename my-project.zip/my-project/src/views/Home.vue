<template>
  <div>
    <h1>主页</h1>
    <router-link to="/login">登录</router-link>
    <router-link to="/register">注册</router-link>
    <router-link to="/forum">论坛</router-link>
    <router-link to="/profile">个人信息</router-link>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
