<template>
  <div>
    <h1>论坛</h1>
    <div v-for="post in posts" :key="post.id">
      <h2>{{ post.title }}</h2>
      <p>{{ post.content }}</p>
    </div>
    <form @submit.prevent="createPost">
      <input v-model="newPost.title" placeholder="帖子标题" required />
      <textarea v-model="newPost.content" placeholder="帖子内容" required></textarea>
      <button type="submit">发布</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      posts: [],
      newPost: {
        title: '',
        content: '',
      },
    };
  },
  async created() {
    await this.fetchPosts();
  },
  methods: {
    async fetchPosts() {
      try {
        const response = await axios.get('/posts');
        this.posts = response.data;
      } catch (error) {
        console.error(error);
      }
    },
    async createPost() {
      try {
        await axios.post('/posts', this.newPost);
        this.newPost.title = '';
        this.newPost.content = '';
        await this.fetchPosts();
      } catch (error) {
        console.error(error);
      }
    },
  },
};
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
