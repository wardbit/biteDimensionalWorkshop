<template>
  <div>
    <h1>个人信息</h1>
    <div v-if="user">
      <p>用户名: {{ user.username }}</p>
      <img :src="user.avatar_url" alt="头像" />
      <router-link to="/forum">返回论坛</router-link>
    </div>
    <div v-else>
      <p>加载中...</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      user: null,
    };
  },
  async created() {
    try {
      const response = await axios.get('/user');
      this.user = response.data;
    } catch (error) {
      console.error(error);
    }
  },
};
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
