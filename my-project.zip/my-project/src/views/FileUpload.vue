<template>
  <div>
    <h1>上传头像</h1>
    <form @submit.prevent="upload">
      <input v-model="username" placeholder="用户名" required />
      <input type="file" @change="onFileChange" required />
      <button type="submit">上传</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      username: '',
      file: null,
    };
  },
  methods: {
    onFileChange(e) {
      this.file = e.target.files[0];
    },
    async upload() {
      const formData = new FormData();
      formData.append('username', this.username);
      formData.append('photo', this.file);

      try {
        const response = await axios.post('/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        console.log(response.data);
        // 处理上传成功
      } catch (error) {
        console.error(error);
      }
    },
  },
};
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
