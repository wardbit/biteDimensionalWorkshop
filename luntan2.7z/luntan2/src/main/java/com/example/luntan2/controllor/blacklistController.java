package com.example.luntan2.controllor;

public class blacklistController {
}
